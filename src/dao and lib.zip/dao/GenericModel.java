package dao;

public class GenericModel {
}
