package dao;

public enum SpecialScope{
    ALL,
    BRAND,
    NEWORUSED,
    YEAR,
    BODYTYPE,
    UNIQUEONE
}