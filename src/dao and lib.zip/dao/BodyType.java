package dao;

public enum BodyType {
    VAN,
    SUV,
    CAR,
    TRUCK
}